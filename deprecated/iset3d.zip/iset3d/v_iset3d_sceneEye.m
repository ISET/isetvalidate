% Validate sceneEye examples
%

%%
warning('Needs updating to deal with CPU configuration.  BW to do.')

% This script does not work properly
%
% t_slantedBarMTF;
% 
% BW to fix.


